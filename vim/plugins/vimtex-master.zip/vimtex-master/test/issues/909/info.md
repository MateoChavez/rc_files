# Test results

|----+-------------+-------+----------------+-----------|
| OS | Vim version | Works | Reported by    | Note      |
|---:+-------------+-------+----------------+-----------|
|  7 | 7.4.965     | No    | @Chiel92       |           |
| 10 | 8.0.69      | No    | @lervag        | cmd.exe   |
| 10 | 8.0.685     | Yes   | @fuzzybear3965 | laptop    |
| 10 | 8.0.685     | Yes   | @fuzzybear3965 | desktop   |
| 10 | 8.0.69      | Yes   | @lervag        | Git shell |
|----+-------------+-------+----------------+-----------|

